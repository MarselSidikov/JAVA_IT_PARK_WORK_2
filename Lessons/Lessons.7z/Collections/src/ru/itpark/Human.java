package ru.itpark;

/**
 * Created by Student21 on 04.06.2017.
 */
public class Human {
}
