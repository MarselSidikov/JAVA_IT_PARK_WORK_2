class Program {
	public static void main(String[] args) {
		boolean some = true;
		some = false;

		int i = 10;

		some = i < 20; // some - true
		some = i > 30; // some - false

		// бесконечный цикл
		while (true) {

		}
	}
}