package ru.itpark.overload;

/**
 * Created by Student21 on 19.05.2017.
 */
public class Summator {
    public int sum(int a, int b) {
        return a + b;
    }

    public int sum(int a, int b, int c) {
        return a + b + c;
    }

    /*
    public double sum(int a, int b) {
        return a + b;
    }
    */
}
