package ru.itpark;

public class Program {
    public static void main(String[] args) {
        Human human = new Human(23, "Marsel", "male", 185);
        System.out.println(human);
    }
}
