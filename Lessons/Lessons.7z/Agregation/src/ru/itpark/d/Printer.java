package ru.itpark.d;


public interface Printer {
    void printCheck(int cash);
}
