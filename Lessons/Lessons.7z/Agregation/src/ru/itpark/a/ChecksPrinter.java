package ru.itpark.a;

public class ChecksPrinter {
    public void printCheck(int cash) {
        System.out.println("You get " + cash);
    }

    public void killClient() {
        System.out.println("You died");
    }
}
