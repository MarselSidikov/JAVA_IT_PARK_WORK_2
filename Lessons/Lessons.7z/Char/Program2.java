class Program2 {
	public static void main(String args[]) {
		char text[] = 
			{'H','e','l','\t','l','o','\n','I','v','a','n'};
		
		for (int i = 0; i < text.length; i++) {
			System.out.print(text[i]);
		}
	}
}