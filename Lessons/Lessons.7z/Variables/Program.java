class Program {
	public static void main(String args[]) {
		// Replacing variables
		/*
		int a = 6;
		int b = 7;
		
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		
		int temp = a;
		a = b;
		b = temp;
		
		System.out.println("After replace:");
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		*/
		int x = 7;
		int y = 3;
		int c = x / y; // 7 = 2 * 3 + 1
		System.out.println(c);
		int d = x % y; // d - 1,
	}
}