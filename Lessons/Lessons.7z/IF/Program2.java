import java.util.Scanner;

class Program2 {
	public static void main(String args[]) {
		Scanner scanner = new Scanner(System.in);
		
		int number = scanner.nextInt();
		int number = 0
		while (a <= number)
		
		if (number % a == 0) {
			System.out.println("EVEN");
			
			if (number > a == 1) {
				System.out.println("NOT EVEN");
			}
		}
		
			if (number % a == 0) {
			System.out.println("EVEN and END NUMBER");
		}
		
			if (number % a == 1 || number % a == 0) {
			System.out.println("NOT EVEN or END NUMBER");
		}
	}
}